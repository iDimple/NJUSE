import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by Alisa on 17/2/14.
 */
public class InitSnow {
    public static Connection conn;



    public static void main(String[] args) {

        try {
            conn = SnowHelper.getConnection();
            conn.setAutoCommit(false);
            System.out.println("开始建表,插入测试数据...");
            createTables();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTables() {
        createcity();
        createProvince();
        createTime();
        createEmployee();
        createDepartment();
        createHr();
        createCustomer();
        createFeedback();
        createCs();
        createproduct();
        createpm();
        createyx();
        createyxm();
        createasset();
        createassetm();
    }


    //创建时间维表
    public static void createTime() {
        String Drop = "drop table if exists `time`;";
        String Create = "create table `time`( " +
                "`timeid` int(11) AUTO_INCREMENT," +
                "`day` int(2) ," +
                "`month` int(2) ," +
                "`year` int(2) ," +
                "primary key(`timeid`) " +
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建详细地址表
    public static void createcity() {
        String Drop = "drop table if exists city;";
        String Create = "create table city" + "( "
                + "id varchar(20) ,"
                + "city varchar(20) ,"
                + "address varchar(255) ,"
                + "primary key(id)"+
                " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }


    //创建员工维表
    public static void createEmployee() {
        String Drop = "drop table if exists employee;";
        String Create = "create table employee" + "( "
                + "eid int(11) ,"
                + "ename varchar(20) ,"
                + "position varchar(20) ,"
                + "addressid int(11) ,"
                + "phone varchar(11) ,"
                + "primary key(eid)"+
                " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建部门维表
    public static void createDepartment() {
        String Drop = "drop table if exists `department`;";
        String Create = "create table `department`( " +
                "`dno` int(11)," +
                "`name` varchar(20) ," +
                "`managerid` int(11) ," +
                "primary key(`dno`) " +
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }


    //创建客户维表
    public static void createCustomer() {
        String Drop = "drop table if exists `customer`;";
        String Create = "create table `customer`( " +
                "`cid` int(11)," +
                "`name` varchar(20) ," +
                "`phone` varchar(11) ," +
                "primary key(`cid`) " +
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建反馈维表
    public static void createFeedback() {
        String Drop = "drop table if exists `feedback`;";
        String Create = "create table `feedback`( " +
                "`fid` int(11)," +
                "`dno` int(11) ," +
                "`description` varchar(255) ," +
                "primary key(`fid`), " +
                "CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE "+
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建省表
    public static void createProvince() {
        String Drop = "drop table if exists province;";
        String Create = "create table province" + "( "
                + "id int(11) ,"
                + "cityid varchar(20) ,"
                + "primary key(id)"+
                " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建产品维表
    public static void createproduct() {
        String Drop = "drop table if exists product;";
        String Create = "create table product" + "( "
                + "bid int(11),"
                + "name varchar(20) ,"
                + "description varchar(255) ,"
                + "cost double ,"
                + "primary key(bid)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    //创建营销活动维表
    public static void createyx() {
        String Drop = "drop table if exists yx;";
        String Create = "create table yx" + "( "
                + "yxid int(11) ,"
                + "name varchar(20) ,"
                + "description varchar(255) ,"
                + "benefit double  ,"
                + "bid int(11) ,"
                + "eid int(11) ,"
                + "aim double ,"
                + "primary key(yxid),"
                +"CONSTRAINT `yx_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `yx_ibfk_2` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE "+
                " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }


    //创建资金维表
    public static void createasset() {
        String Drop = "drop table if exists asset;";
        String Create = "create table asset" + "( "
                + "aid int(11) ,"
                + "description varchar(255) ,"
                + "primary key(aid)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    //创建资产管理维表
    public static void createassetm() {
        String Drop = "drop table if exists `assetm`;";
        String Create = "create table `assetm`( " +
                "`timeid` int(11)," +
                "`dno` int(11) ," +
                "`aid` int(11) ," +
                "`in` double ," +
                "`out` double ," +
                "primary key(`timeid`,`dno`,`aid`) ," +
                "CONSTRAINT `assetm_ibfk_1` FOREIGN KEY (`timeid`) REFERENCES `time` (`timeid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `assetm_ibfk_2` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `assetm_ibfk_3` FOREIGN KEY (`aid`) REFERENCES `asset` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE "+
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建人事管理事实表
    public static void createHr() {
        String Drop = "drop table if exists `hr`;";
        String Create = "create table `hr`( " +
                "`timeid` int(11)," +
                "`dno` int(11) ," +
                "`eid` int(11) ," +
                "`score` int(11) ," +
                "primary key(`timeid`,`dno`,`eid`) ," +
                "CONSTRAINT `hr_ibfk_1` FOREIGN KEY (`timeid`) REFERENCES `time` (`timeid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `hr_ibfk_2` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `hr_ibfk_3` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE "+
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建客户管理事实表
    public static void createCs() {
        String Drop = "drop table if exists `cs`;";
        String Create = "create table `cs`( " +
                "`timeid` int(11)," +
                "`cid` int(11) ," +
                "`eid` int(11) ," +
                "`fid` int(11) ," +
                "`satisfy` double ," +
                "primary key(`timeid`,`cid`,`eid`,`fid`) ," +
                "CONSTRAINT `cs_ibfk_1` FOREIGN KEY (`timeid`) REFERENCES `time` (`timeid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `cs_ibfk_2` FOREIGN KEY (`cid`) REFERENCES `customer` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `cs_ibfk_3` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `cs_ibfk_4` FOREIGN KEY (`fid`) REFERENCES `feedback` (`fid`) ON DELETE CASCADE ON UPDATE CASCADE "+
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建产品管理事实表
    public static void createpm() {
        String Drop = "drop table if exists `pm`;";
        String Create = "create table `pm`( " +
                "`timeid` int(11)," +
                "`cid` int(11) ," +
                "`bid` int(11) ," +
                "`fid` int(11) ," +
                "`profit` double ," +
                "`satisfy` double ," +
                "primary key(`timeid`,`cid`,`bid`,`fid`) ," +
                "CONSTRAINT `pm_ibfk_1` FOREIGN KEY (`timeid`) REFERENCES `time` (`timeid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `pm_ibfk_2` FOREIGN KEY (`cid`) REFERENCES `customer` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `pm_ibfk_3` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `pm_ibfk_4` FOREIGN KEY (`fid`) REFERENCES `feedback` (`fid`) ON DELETE CASCADE ON UPDATE CASCADE "+
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    //创建营销管理事实表
    public static void createyxm() {
        String Drop = "drop table if exists `yxm`;";
        String Create = "create table `yxm`( " +
                "`timeid` int(11)," +
                "`cid` int(11) ," +
                "`fid` int(11) ," +
                "`yxid` int(11) ," +
                "`profit` double ," +
                "`satisfy` double ," +
                "primary key(`timeid`,`cid`,`fid`,`yxid`) ," +
                "CONSTRAINT `yxm_ibfk_1` FOREIGN KEY (`timeid`) REFERENCES `time` (`timeid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `yxm_ibfk_2` FOREIGN KEY (`fid`) REFERENCES `feedback` (`fid`) ON DELETE CASCADE ON UPDATE CASCADE ,"+
                "CONSTRAINT `yxm_ibfk_3` FOREIGN KEY (`yxid`) REFERENCES `yx` (`yxid`) ON DELETE CASCADE ON UPDATE CASCADE "+
                "     ) DEFAULT CHARSET=utf8;";
        createTable(Drop);
        createTable(Create);
    }
    public static void createTable(String sql) {
        try {
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            Statement statement = conn.createStatement();
            statement.addBatch(sql);
            statement.executeBatch();
            conn.commit();
            System.out.println("初始化表成功");
        } catch (SQLException e) {
            System.out.println("初始化表失败");
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            e.printStackTrace();
        }
    }
}
