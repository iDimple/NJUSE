import java.sql.*;

/**
 * Created by Alisa on 17/2/13.
 */
public class EtlStar {
    public static Connection econn;
    public static Connection sconn;

    public static void main(String[] args) {
        EtlStar a = new EtlStar();
        a.etlHr();
        a.etlCs();
        a.etlPRODUCT();
        a.etlyxm();
        a.etlCaiwu();
        try {
            econn.close();
            sconn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    //etl人事管理
    public void etlHr() {
        try {
            econn = SqlHelper.getConnection();
            econn.setAutoCommit(false);
            sconn = StarHelper.getConnection();
            sconn.setAutoCommit(false);
            System.out.println("start etl hr");
            PreparedStatement psHr = sconn.prepareStatement
                    ("insert into  hr(timeid,dno,eid,score) values(?,?,?,?) ");
            PreparedStatement psEmployee = sconn.prepareStatement
                    ("insert into  employee(eid,ename,position,address,phone) values(?,?,?,?,?) ");
            PreparedStatement psDepartment = sconn.prepareStatement
                    ("insert into  department(dno,name,managerid) values(?,?,?) ");
            PreparedStatement psTime = sconn.prepareStatement
                    ("insert into  time(timeid,day,month,year) values(?,?,?,?) ");
            try {
                PreparedStatement ps = econn.prepareStatement
                        ("select * from chuqing ");

                ResultSet rs = ps.executeQuery();
                econn.commit();

                while (rs.next()) {
                    System.out.println("sss");
                    int eid = rs.getInt(2);
                    Date time = rs.getDate(3);
                    int type = rs.getInt(4);
                    //插入数据到时间维表

                    psTime.setInt(1, time.hashCode());
                    psTime.setInt(2, time.getDay());
                    psTime.setInt(3, time.getMonth());
                    psTime.setInt(4, time.getYear());
                    psTime.executeUpdate();
                    //插入数据到员工维表
                    psEmployee.setInt(1, eid);
                    ps = econn.prepareStatement
                            ("select * from employee where eid=? ");
                    ps.setInt(1, eid);
                    ResultSet rs1 = ps.executeQuery();
                    econn.commit();
                    int dno = 0;
                    if (rs1.next()) {
                        psEmployee.setInt(1, rs1.getInt(1));
                        psEmployee.setString(2, rs1.getString(2));
                        psEmployee.setString(3, rs1.getString(4));
                        psEmployee.setString(4, rs1.getString(6));
                        psEmployee.setString(5, rs1.getString(7));
                        dno = rs1.getInt(3);
                        psEmployee.executeUpdate();
                    }
                    System.out.println(dno);
                    //插入数据到部门维表
                    ps = econn.prepareStatement
                            ("select * from department where dno=? ");
                    ps.setInt(1, dno);
                    ResultSet rs2 = ps.executeQuery();
                    econn.commit();
                    if (rs2.next()) {
                        psDepartment.setInt(1, dno);
                        psDepartment.setString(2, rs2.getString(2));
                        psDepartment.setInt(3, rs2.getInt(3));
                        psDepartment.executeUpdate();
                    }
                    //插入数据到人事事实表
                    psHr.setInt(1, time.hashCode());
                    psHr.setInt(2, dno);
                    psHr.setInt(3, eid);
                    psHr.setInt(4, type);
                    psHr.executeUpdate();
                    sconn.commit();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


            //econn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("success etl hr");
    }

    //etl客户服务
    public void etlCs() {
        try {
            econn = SqlHelper.getConnection();
            econn.setAutoCommit(false);
            sconn = StarHelper.getConnection();
            sconn.setAutoCommit(false);
            System.out.println("start etl cs");
            PreparedStatement psCs = sconn.prepareStatement
                    ("insert into  cs(timeid,cid,eid,fid,satisfy) values(?,?,?,?,?) ");
            PreparedStatement psEmployee = sconn.prepareStatement
                    ("insert into  employee(eid,ename,position,address,phone) values(?,?,?,?,?) ");
            PreparedStatement pscustomer = sconn.prepareStatement
                    ("insert into  customer(cid,name,phone) values(?,?,?) ");
            PreparedStatement psfeedback = sconn.prepareStatement
                    ("insert into  feedback(fid,dno,description) values(?,?,?) ");
            PreparedStatement psTime = sconn.prepareStatement
                    ("insert into  time(timeid,day,month,year) values(?,?,?,?) ");
            try {
                PreparedStatement ps = econn.prepareStatement
                        ("select * from complain ");

                ResultSet rs = ps.executeQuery();
                econn.commit();

                while (rs.next()) {
                    int eid = rs.getInt(5);
                    Date time = rs.getDate(3);
                    int cid = rs.getInt(4);
                    int type = rs.getInt(6);
                    int score = rs.getInt(7);
                    //插入数据到时间维表
                    int fid = cid;
                    psTime.setInt(1, time.hashCode());
                    psTime.setInt(2, time.getDay());
                    psTime.setInt(3, time.getMonth());
                    psTime.setInt(4, time.getYear());
                    psTime.executeUpdate();

//插入数据到客户维表
                    ps = econn.prepareStatement
                            ("select * from phonecust where cid=? ");
                    ps.setInt(1, cid);
                    ResultSet rs2 = ps.executeQuery();
                    econn.commit();
                    if (rs2.next()) {
                        pscustomer.setInt(1, fid);
                        pscustomer.setString(2, rs2.getString(2));
                        pscustomer.setString(3, rs2.getString(5));
                        pscustomer.executeUpdate();
                    }
                    //插入信息到反馈信息维表
                    psfeedback.setInt(1, cid);
                    psfeedback.setInt(2, type);
                    psfeedback.setString(3, rs.getString(2));
                    psfeedback.executeUpdate();
                    //插入数据到客服管理事实表
                    psCs.setInt(1, time.hashCode());
                    psCs.setInt(2, cid);
                    psCs.setInt(3, eid);
                    psCs.setInt(4, fid);
                    psCs.setInt(5, score);
                    psCs.executeUpdate();
                    sconn.commit();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


            //econn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("success etl cs");
    }

    //etl产品管理
    public void etlPRODUCT() {
        try {
            econn = SqlHelper.getConnection();
            econn.setAutoCommit(false);
            sconn = StarHelper.getConnection();
            sconn.setAutoCommit(false);
            System.out.println("start etl PRODUCT");
            PreparedStatement psPm = sconn.prepareStatement
                    ("insert into  pm(timeid,cid,bid,fid,profit,satisfy) values(?,?,?,?,?,?) ");
            PreparedStatement pscustomer = sconn.prepareStatement
                    ("insert into  customer(cid,name,phone) values(?,?,?) ");
            PreparedStatement psfeedback = sconn.prepareStatement
                    ("insert into  feedback(fid,dno,description) values(?,?,?) ");
            PreparedStatement psTime = sconn.prepareStatement
                    ("insert into  time(timeid,day,month,year) values(?,?,?,?) ");
            PreparedStatement psproduct = sconn.prepareStatement
                    ("insert into  product(bid,name,description,cost) values(?,?,?,?) ");
            try {
                PreparedStatement ps = econn.prepareStatement
                        ("select * from complain ");

                ResultSet rs = ps.executeQuery();
                econn.commit();

                while (rs.next()) {
                    int eid = rs.getInt(5);
                    Date time = rs.getDate(3);
                    int cid = rs.getInt(4);
                    int type = rs.getInt(6);
                    int score = rs.getInt(7);
                    int fid = cid;
                    //插入数据到产品表
                    ps = econn.prepareStatement
                            ("select * from product where bid=? ");
                    ps.setInt(1, type);
                    ResultSet rs3 = ps.executeQuery();
                    econn.commit();
                    double profit = 0;
                    if (rs3.next()) {
                        psproduct.setInt(1, rs3.getInt(1));
                        psproduct.setString(2, rs3.getString(2));
                        psproduct.setString(3, rs3.getString(3));
                        psproduct.setDouble(4, rs3.getDouble(6));
                        psproduct.executeUpdate();
                        profit = rs3.getDouble(4) - rs3.getDouble(6);
                    }

                    //插入数据到产品管理事实表
                    psPm.setInt(1, time.hashCode());
                    psPm.setInt(2, cid);
                    psPm.setInt(3, type);
                    psPm.setInt(4, fid);
                    psPm.setDouble(5, profit);
                    psPm.setInt(6, score);
                    psPm.executeUpdate();
                    sconn.commit();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


            // econn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("success etl productm");
    }


    //et营销管理
    public void etlyxm() {
        try {
            econn = SqlHelper.getConnection();
            econn.setAutoCommit(false);
            sconn = StarHelper.getConnection();
            sconn.setAutoCommit(false);
            System.out.println("start etl yx");
            PreparedStatement psYxm = sconn.prepareStatement
                    ("insert into  yxm(timeid,cid,fid,yxid,profit,satisfy) values(?,?,?,?,?,?) ");
            PreparedStatement psyx = sconn.prepareStatement
                    ("insert into  employee(yxid,name,description,benefit,bid,eid,aim) values(?,?,?,?,?,?,?) ");
            PreparedStatement pscustomer = sconn.prepareStatement
                    ("insert into  customer(cid,name,phone) values(?,?,?) ");
            PreparedStatement psfeedback = sconn.prepareStatement
                    ("insert into  feedback(fid,dno,description) values(?,?,?) ");
            PreparedStatement psTime = sconn.prepareStatement
                    ("insert into  time(timeid,day,month,year) values(?,?,?,?) ");
            try {
                PreparedStatement ps = econn.prepareStatement
                        ("select * from yx ");

                ResultSet rs = ps.executeQuery();
                econn.commit();

                while (rs.next()) {
                    int eid = rs.getInt(9);
                    Date time = rs.getDate(5);
                    int bid = rs.getInt(8);
                    double aim = rs.getDouble(10);
                    String description = rs.getString(3);
                    String name = rs.getString(2);
                    int yxid = rs.getInt(1);
                    double benefit = rs.getDouble(4);
                    //插入数据到时间维表

                    psTime.setInt(1, time.hashCode());
                    psTime.setInt(2, time.getDay());
                    psTime.setInt(3, time.getMonth());
                    psTime.setInt(4, time.getYear());
                    psTime.executeUpdate();

//插入数据到客户维表
                    ps = econn.prepareStatement
                            ("select * from subscribe where yxid=? ");
                    ps.setInt(1, yxid);
                    ResultSet rs2 = ps.executeQuery();
                    econn.commit();
                    int cid = 1;
                    if (rs2.next()) {
                        cid = rs.getInt(4);
                    }
                    ps = econn.prepareStatement
                            ("select * from phonecust where cid=? ");
                    ps.setInt(1, cid);
                    ResultSet rs3 = ps.executeQuery();
                    econn.commit();
                    if (rs3.next()) {
                        pscustomer.setInt(1, cid);
                        pscustomer.setString(2, rs3.getString(2));
                        pscustomer.setString(3, rs3.getString(5));
                        pscustomer.executeUpdate();
                    }
                    //插入信息到反馈信息维表
                    ps = econn.prepareStatement
                            ("select * from consult where id=? ");
                    ps.setInt(1, yxid);
                    ResultSet rs4 = ps.executeQuery();
                    econn.commit();
                    int type = 0;
                    int fid = 0;
                    int score = 0;
                    if (rs4.next()) {
                        type = rs4.getInt(5);
                        fid = rs4.getInt(1);
                        score = rs4.getInt(6);
                    }
                    psfeedback.setInt(1, cid);
                    psfeedback.setInt(2, type);
                    psfeedback.setString(3, rs.getString(2));
                    psfeedback.executeUpdate();
                    //插入数据到营销管理事实表
                    System.out.println(cid);
                    psYxm.setInt(1, time.hashCode());
                    psYxm.setInt(2, cid);
                    psYxm.setInt(3, fid);
                    psYxm.setInt(4, yxid);
                    psYxm.setDouble(5, benefit);
                    psYxm.setDouble(6, score);
                    psYxm.executeUpdate();
                    sconn.commit();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


            //econn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("success etl yx");
    }

    //etl人事管理
    public void etlCaiwu() {
        try {
            econn = SqlHelper.getConnection();
            econn.setAutoCommit(false);
            sconn = StarHelper.getConnection();
            sconn.setAutoCommit(false);
            System.out.println("start etl caiwu");
            PreparedStatement psAssetM = sconn.prepareStatement
                    ("insert into  assetm(timeid,dno,aid,`in`,`out`) values(?,?,?,?,?) ");
            PreparedStatement psAseet = sconn.prepareStatement
                    ("insert into  asset(aid,description) values(?,?) ");
            PreparedStatement psDepartment = sconn.prepareStatement
                    ("insert into  department(dno,name,managerid) values(?,?,?) ");
            PreparedStatement psTime = sconn.prepareStatement
                    ("insert into  time(timeid,day,month,year) values(?,?,?,?) ");
            try {
                PreparedStatement ps = econn.prepareStatement
                        ("select * from asset ");

                ResultSet rs = ps.executeQuery();
                econn.commit();

                while (rs.next()) {
                    int aid = rs.getInt(1);
                    Date time = rs.getDate(5);
                    String type = rs.getString(3);
                    String description = rs.getString(2);
                    int dno = rs.getInt(4);
                    double money = rs.getDouble(6);
                    //插入数据到时间维表

                    psTime.setInt(1, time.hashCode());
                    psTime.setInt(2, time.getDay());
                    psTime.setInt(3, time.getMonth());
                    psTime.setInt(4, time.getYear());
                    psTime.executeUpdate();

                    //插入数据到部门维表
                    ps = econn.prepareStatement
                            ("select * from department where dno=? ");
                    ps.setInt(1, dno);
                    ResultSet rs2 = ps.executeQuery();
                    econn.commit();
                    if (rs2.next()) {
                        psDepartment.setInt(1, dno);
                        psDepartment.setString(2, rs2.getString(2));
                        psDepartment.setInt(3, rs2.getInt(3));
                        psDepartment.executeUpdate();
                    }
                    //插入数据到资金维表
                    psAseet.setInt(1, aid);
                    psAseet.setString(2, description);
                    psAseet.executeUpdate();
                    //插入数据到人事事实表
                    psAssetM.setInt(1, time.hashCode());
                    psAssetM.setInt(2, dno);
                    psAssetM.setInt(3, aid);
                    if (type.equals("in")) {
                        psAssetM.setDouble(4, money);
                        psAssetM.setDouble(5, 0);
                    } else {
                        psAssetM.setDouble(5, money);
                        psAssetM.setDouble(4, 0);
                    }
                    psAssetM.executeUpdate();
                    sconn.commit();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


            //econn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("success etl caiwu");
    }
}

