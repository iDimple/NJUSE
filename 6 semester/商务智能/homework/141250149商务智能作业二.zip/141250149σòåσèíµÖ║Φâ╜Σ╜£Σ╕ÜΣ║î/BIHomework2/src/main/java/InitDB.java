import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by Alisa on 17/2/11.
 */
public class InitDB {
    public static Connection conn;


    public static void main(String[] args) {

        try {
            conn = SqlHelper.getConnection();
            conn.setAutoCommit(false);
            System.out.println("开始建表,插入测试数据...");
            createTables();

            insertData();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTables() {

        createDepartment();
        createEmployee();
        createChuqing();
        createSalary();
        createDepartmentIncome();
        createDepartmentOutcome();
        createAsset();
        createmember();
        createproduct();
        createPhoneCust();
        createComplain();
        createConsult();
        createSubscribe();
        createUnsubscribe();
        createdeposit();
        createyx();
        createChuqing();
    }

    public static void insertData() {
        String insertDepartment = "load data local infile 'department.txt'" +
                "into table department(dno,dname,managerId);";
        String insertEmployee = "load data local infile 'employee.txt'" +
                "into table employee(eid,ename,dno,position,identityCard,address,phone);";
        String insertChuqing = "load data local infile 'chuqing.txt'" +
                "into table chuqing(id,eid,time,type);";
        String insertdeposit = "load data local infile 'deposit.txt'" +
                "into table deposit(id,description,time,mid,eid,dno,money);";
        String insertConsult = "load data local infile 'consult.txt'" +
                "into table consult(id,description,time,cid,eid,bid);";
        String insertcomplain = "load data local infile 'complain.txt'" +
                "into table complain(id,description,time,cid,eid,bid,score);";
        String insertasset = "load data local infile 'asset.txt'" +
                "into table asset(id,description,type,dno,time,money,total);";
        String insertincome = "load data local infile 'income.txt'" +
                "into table departmentincome(id,dno,time,money,description,type);";
        String insertoutcome = "load data local infile 'outcome.txt'" +
                "into table departmentoutcome(id,dno,time,money,description,type);";
        String insertphonecust = "load data local infile 'phonecust.txt'" +
                "into table phonecust(cid,cname,type,mid,phone);";
        String insertsubscribe = "load data local infile 'subscribe.txt'" +
                "into table subscribe(id,description,time,mid,eid,dno,bid,yxid);";
        String insertunsub = "load data local infile 'unsubscribe.txt'" +
                "into table unsubscribe(id,description,time,mid,eid,dno,bid);";
        String insertyx = "load data local infile 'yx.txt'" +
                "into table yx(id,name,description,benefit,time,btime,etime,bid,eid,aim);";
        String insertsalary = "load data local infile 'salary.txt'" +
                "into table salary(id,eid,time,money,position);";
        String insertproduct = "load data local infile 'product.txt'" +
                "into table product(bid,name,description,price,time,cost,yxid);";
        String insertmember = "load data local infile 'member.txt'" +
                "into table member(mid,mname,level,idcard,phone,birthday,time,money);";
        try {
            Statement statement = conn.createStatement();
            statement.addBatch(insertphonecust);
            statement.addBatch(insertmember);
            statement.addBatch(insertDepartment);
            statement.addBatch(insertEmployee);
            statement.addBatch(insertincome);
            statement.addBatch(insertoutcome);
            statement.addBatch(insertsalary);
            statement.addBatch(insertasset);
            statement.addBatch(insertChuqing);
            statement.addBatch(insertproduct);
            statement.addBatch(insertyx);
            statement.addBatch(insertdeposit);
            statement.addBatch(insertConsult);
            statement.addBatch(insertcomplain);
            statement.addBatch(insertsubscribe);
            statement.addBatch(insertunsub);
            statement.executeBatch();
            conn.commit();
            System.out.println("导入数据成功");
        } catch (SQLException e) {
            System.out.println("导入数据失败");
            e.printStackTrace();
        }


    }


    public static void createDepartment() {

        String depDrop = "drop table if exists `department`;";
        String depCreate = "create table `department`( " +
                "     `dno` int(11),`dname` varchar(20) ,`managerId` int(11) ,primary key(`dno`)" +
                "     ) DEFAULT CHARSET=utf8;";
        createTable(depDrop);
        createTable(depCreate);
    }

    public static void createEmployee() {
        String Drop = "drop table if exists employee;";
        String Create = "create table employee" + "( "
                + "eid int(11) not null,"
                + "ename varchar(20) ,"
                + "dno int(11) not null,"
                + "position varchar(20) ,"
                + "identityCard varchar(18) ,"
                + "address varchar(255) ,"
                + "phone varchar(11) ,"
                + "primary key(eid)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }


    public static void createSalary() {
        String Drop = "drop table if exists salary;";
        String Create = "create table salary" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "eid int(11) ,"
                + "time datetime ,"
                + "money double not null,"
                + "position varchar(20) ,"
                + "primary key(id)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createDepartmentIncome() {
        String Drop = "drop table if exists departmentincome;";
        String Create = "create table departmentincome" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "dno int(11) ,"
                + "time datetime ,"
                + "money double not null,"
                + "description varchar(255) ,"
                + "type varchar(255) ,"
                + "primary key(id),"
                + "CONSTRAINT `departmentincome_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createDepartmentOutcome() {
        String Drop = "drop table if exists departmentoutcome;";
        String Create = "create table departmentoutcome" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "dno int(11) ,"
                + "time datetime ,"
                + "money double not null,"
                + "description varchar(255) ,"
                + "type varchar(255) ,"
                + "primary key(id),"
                + "CONSTRAINT `departmentoutcome_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createAsset() {
        String Drop = "drop table if exists asset;";
        String Create = "create table asset" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "description varchar(255) ,"
                + "type enum('in ', 'out') not null ,"
                + "dno int(11) ,"
                + "time datetime ,"
                + "money double not null,"
                + "total double not null,"
                + "primary key(id),"
                + "CONSTRAINT `asset_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createmember() {
        String Drop = "drop table if exists member;";
        String Create = "create table member" + "( "
                + "mid int(11) AUTO_INCREMENT,"
                + "mname varchar(20) ,"
                + "level int(3) not null,"
                + "idcard varchar(18) not null,"
                + "phone varchar(11) ,"
                + "birthday datetime ,"
                + "time datetime ,"
                + "money double ,"
                + "primary key(mid)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createChuqing() {
        String Drop = "drop table if exists chuqing;";
        String Create = "create table chuqing" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "eid int(11) ,"
                + "time datetime ,"
                + "type int(1) ,"
                + "primary key(id)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createproduct() {
        String Drop = "drop table if exists product;";
        String Create = "create table product" + "( "
                + "bid int(11) AUTO_INCREMENT,"
                + "name varchar(20) ,"
                + "description varchar(255) ,"
                + "price double ,"
                + "time datetime ,"
                + "cost double ,"
                + "yxid int(11) default null,"
                + "primary key(bid)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createPhoneCust() {
        String Drop = "drop table if exists phonecust;";
        String Create = "create table phonecust" + "( "
                + "cid int(11) AUTO_INCREMENT,"
                + "cname varchar(20) ,"
                + "type enum('member ', 'not') not null ,"
                + "mid int(11) ,"
                + "phone varchar(11) ,"
                + "primary key(cid)"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createComplain() {
        String Drop = "drop table if exists complain;";
        String Create = "create table complain" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "description varchar(255) ,"
                + "time datetime ,"
                + "cid int(11) ,"
                + "eid int(11) ,"
                + "bid int(11) ,"
                + "score int(11) ,"
                + "primary key(id),"
                + "CONSTRAINT `complain_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `phonecust` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `complain_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createConsult() {
        String Drop = "drop table if exists consult;";
        String Create = "create table consult" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "description varchar(255) ,"
                + "time datetime ,"
                + "cid int(11) ,"
                + "eid int(11) ,"
                + "bid int(11) ,"
                + "primary key(id),"
                + "CONSTRAINT `consult_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `phonecust` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `consult_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createSubscribe() {
        String Drop = "drop table if exists subscribe;";
        String Create = "create table subscribe" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "description varchar(255) ,"
                + "time datetime ,"
                + "mid int(11) ,"
                + "eid int(11) ,"
                + "dno int(11) ,"
                + "bid int(11) ,"
                + "yxid int(11) ,"
                + "primary key(id),"
                + "CONSTRAINT `subscribe_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `subscribe_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `subscribe_ibfk_3` FOREIGN KEY (`mid`) REFERENCES `member` (`mid`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createUnsubscribe() {
        String Drop = "drop table if exists unsubscribe;";
        String Create = "create table unsubscribe" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "description varchar(255) ,"
                + "time datetime ,"
                + "mid int(11) ,"
                + "eid int(11) ,"
                + "dno int(11) ,"
                + "bid int(11) ,"
                + "primary key(id),"
                + "CONSTRAINT `unsubscribe_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `unsubscribe_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `unsubscribe_ibfk_3` FOREIGN KEY (`mid`) REFERENCES `member` (`mid`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createdeposit() {
        String Drop = "drop table if exists deposit;";
        String Create = "create table deposit" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "description varchar(255) ,"
                + "time datetime ,"
                + "mid int(11) ,"
                + "eid int(11) ,"
                + "dno int(11) ,"
                + "money double not null ,"
                + "primary key(id),"
                + "CONSTRAINT `deposit_ibfk_1` FOREIGN KEY (`dno`) REFERENCES `department` (`dno`) ON DELETE CASCADE ON UPDATE CASCADE ,"
                + "CONSTRAINT `deposit_ibfk_2` FOREIGN KEY (`mid`) REFERENCES `member` (`mid`) ON DELETE CASCADE ON UPDATE CASCADE"
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createyx() {
        String Drop = "drop table if exists yx;";
        String Create = "create table yx" + "( "
                + "id int(11) AUTO_INCREMENT,"
                + "name varchar(20) ,"
                + "description varchar(255) ,"
                + "benefit double not null ,"
                + "time datetime ,"
                + "btime datetime ,"
                + "etime datetime ,"
                + "bid int(11) ,"
                + "eid int(11) ,"
                + "aim double ,"
                + "primary key(id),"
                + "CONSTRAINT `yx_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `product` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE "
                + " ) default charset=utf8;";
        createTable(Drop);
        createTable(Create);
    }

    public static void createTable(String sql) {
        try {
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            Statement statement = conn.createStatement();
            statement.addBatch(sql);
            statement.executeBatch();
            conn.commit();
            System.out.println("初始化表成功");
        } catch (SQLException e) {
            System.out.println("初始化表失败");
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            e.printStackTrace();
        }
    }


}
